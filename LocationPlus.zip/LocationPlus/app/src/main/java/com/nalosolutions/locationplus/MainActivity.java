package com.nalosolutions.locationplus;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static Button showlocation;
    //private static Button update;
    TextView longtd;
    TextView latd;
    String investor_id;
    EditText investor;
    GPSTracker gps;
    ListView lv;
    String[] names = {"Andy","John","Joseph","Carl","Ogidi"};
    AutoCompleteTextView autoCompleteTextView;
    Autocomp arraydata = new Autocomp(this);

    public Autocomp getArraydata() {
        names = arraydata.fetchedarray;
        return arraydata;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //
        //getArraydata();

        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "SignUp for bulksms @ http://sms.nalosolutions.com", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        longtd = (TextView) findViewById(R.id.longvalue);
        latd = (TextView) findViewById(R.id.latvalue);
        investor = (EditText) findViewById(R.id.investor_id);
        showlocation = (Button) findViewById(R.id.locbtn);
        autoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,names);
        autoCompleteTextView.setAdapter(arrayAdapter);
        //update = (Button) findViewById(R.id.updatbtn);
           // lv = (ListView) findViewById(R.id.lview);

        showlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                investor_id = investor.getText().toString();
                if (investor_id != "" || investor_id != null) {
                    gps = new GPSTracker(MainActivity.this);
                    if (gps.canGetlocation()) {
                        double latitude = gps.getlatitude();
                        double longitude = gps.getlongitude();
                        Toast.makeText(getApplicationContext(), "Your location is -\nlat:" + latitude + "\nlong:" + longitude, Toast.LENGTH_LONG).show();
                        longtd.setText("" + longitude);
                        latd.setText("" + latitude);
                        fetchCoordinates();
                        investor.setText("");
                        Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();

                    } else {
                        gps.showSettingsAlert();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Enter Investor_id", Toast.LENGTH_LONG).show();
                }

            }
        });
        //
        notifyme();
        //load array...
       //Autocomp autocomp = new Autocomp(this);
        //autocomp.execute();
    }
    public void fetchCoordinates(){
        investor_id = investor.getText().toString();
        String longitu = longtd.getText().toString();
        String latitu = latd.getText().toString();
        backend bground = new backend(this);
        bground.execute(investor_id, longitu, latitu);

    }
    public void notifyme(){
        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.drawable.gipcsmall)
                        .setContentTitle("LocationPlus")
                        .setContentText("New coordintes update");
// Creates an explicit intent for an Activity in your app
        Intent resultIntent = new Intent(this, MainActivity.class);

// The stack builder object will contain an artificial back stack for the
// started Activity.
// This ensures that navigating backward from the Activity leads out of
// your application to the Home screen.
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(this);
// Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(MainActivity.class);
// Adds the Intent that starts the Activity to the top of the stack
        stackBuilder.addNextIntent(resultIntent);
        PendingIntent resultPendingIntent =
                stackBuilder.getPendingIntent(
                        0,
                        PendingIntent.FLAG_UPDATE_CURRENT
                );
        mBuilder.setContentIntent(resultPendingIntent);
        NotificationManager mNotificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
// mId allows you to update the notification later on.
        mNotificationManager.notify(getTaskId(), mBuilder.build());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
       /* if (id == R.id.action_settings) {
            return true;
        }*/

        return super.onOptionsItemSelected(item);

    }
}
