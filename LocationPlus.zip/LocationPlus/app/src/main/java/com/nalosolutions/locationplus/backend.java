package com.nalosolutions.locationplus;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by NanaKwasi on 3/9/2016.
 */
public class backend extends AsyncTask<String,Void,String > {
    Context context;
    backend(Context ctxt){
        context = ctxt;
    }
    AlertDialog alertDialog;
    AlertDialog error;
    String results="";
    String Name_enterprise = "";
    @Override
    protected String doInBackground(String... params) {
        String investor = params[0];
        String longitu = params[1];
        String latitu = params[2];
        String conurl = "http://5.9.79.123/gps_itrack/fetchdata.php";
        if (investor.equals("")){
            //error = Ale

        }else {
            try {
                URL url = new URL(conurl);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputstream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedwriter = new BufferedWriter(new OutputStreamWriter(outputstream,"UTF-8"));
                String post_data = URLEncoder.encode("investor","UTF-8")+"="+URLEncoder.encode(investor,"UTF-8")+"&"+URLEncoder.encode("longitu","UTF-8")+"="+URLEncoder.encode(longitu,"UTF-8")+"&"+URLEncoder.encode("latitu","UTF-8")+"="+URLEncoder.encode(latitu,"UTF-8");
                bufferedwriter.write(post_data);
                bufferedwriter.flush();
                bufferedwriter.close();
                outputstream.close();
                InputStream inputsream = httpURLConnection.getInputStream();
                BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(inputsream,"iso-8859-1"));
                String line ="";
                //String results="";
                while ((line = bufferedreader.readLine()) != null){
                    results +="\n" +line;
                }
                bufferedreader.close();
                inputsream.close();
                httpURLConnection.disconnect();
                return results;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {

                JSONArray jArray = new JSONArray(results);

                for(int i=0; i<jArray.length();i++){
                    JSONObject json = jArray.getJSONObject(i);
                    Name_enterprise = Name_enterprise +json.getString("name_enterprise")+"\n";

                }


            } catch (Exception e) {

                Log.e("log_tag", "Error Parsing Data " + e.toString());
            }
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("COORDINATES UPDATE");
        alertDialog.setIcon(R.drawable.gipcsmall);
        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertDialog.cancel();
            }
        });
    }

    @Override
    protected void onPostExecute(String result) {
        alertDialog.setMessage(Name_enterprise);
        alertDialog.show();

    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }
    public void dialognew(){
        AlertDialog.Builder warning =new AlertDialog.Builder(context);
        warning.setMessage(results).setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
               String value = results;
            }
        }).setNegativeButton("RETRY", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alertme=warning.create();
        alertme.setTitle("Search Match");
        alertme.show();
    }
}
